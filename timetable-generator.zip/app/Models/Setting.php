<?php

namespace App\Models;

class Setting extends Model
{
    /**
     * Table this model uses
     *
     * @var string
     */
    protected $table = 'settings';
}
