<?php

namespace App\Models;

class AcademicPeriod extends Model
{
    protected $table = 'academic_periods';
}
