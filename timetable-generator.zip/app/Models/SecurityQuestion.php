<?php

namespace App\Models;

class SecurityQuestion extends Model
{
    /**
     * Table this model uses
     *
     * @var string
     */
    protected $table = 'security_questions';
}
