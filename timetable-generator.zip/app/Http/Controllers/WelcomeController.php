<?php


namespace App\Http\Controllers;


class WelcomeController
{

    public function index(){
        return view('welcome');
    }
}