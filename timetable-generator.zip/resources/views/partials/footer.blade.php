<div class="col-md-12 text-center alert  ">
	Copyright Genius Team {{ date("Y")}}
</div>