
{{-- JQuery --}}
<script src="{!! URL::asset('/vendors/jquery/dist/jquery.min.js') !!}"></script>

{{-- Bootstrap --}}
<script src="{!! URL::asset('/vendors/bootstrap/dist/js/bootstrap.min.js') !!}"></script>

{{-- NProgress --}}
<script src="{!! URL::asset('/vendors/nprogress/nprogress.js') !!}"></script>

<!-- bootstrap-progressbar -->
<script src="{!! URL::asset('/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js') !!}"></script>

{{-- Parsley --}}
<script src="{!! URL::asset('/vendors/parsleyjs/dist/parsley.min.js') !!}"></script>

{{-- Select2 --}}
<script src="{!! URL::asset('/vendors/select2/dist/js/select2.full.min.js') !!}"></script>

{{-- Moment --}}
<script src="{!! URL::asset('/vendors/moment/min/moment.min.js') !!}"></script>

{{-- Pikaday --}}
<script src="{!! URL::asset('/vendors/pikaday/js/pikaday.js') !!}"></script>
<script src="{!! URL::asset('/vendors/pikaday/js/pikaday.jquery.js') !!}"></script>

{{-- PNotify --}}
<script src="{!! URL::asset('/vendors/pnotify/dist/pnotify.js') !!}"></script>
<script src="{!! URL::asset('/vendors/pnotify/dist/pnotify.buttons.js') !!}"></script>
<script src="{!! URL::asset('/vendors/pnotify/dist/pnotify.nonblock.js') !!}"></script>

 <!-- datepicker -->
<script src="{{ URL::asset('vendors/datepicker/bootstrap-datepicker.js') }}"></script>

<!-- timepicker -->
<script src="{{ URL::asset('vendors/timepicker/bootstrap-timepicker.min.js') }}"></script>

 <!-- Tokenizer -->
<script src="{{ URL::asset('vendors/tokenizer/bootstrap-tokenfield.min.js') }}"></script>

{{-- iCheck JS --}}
<script src="{!! URL::asset('/vendors/iCheck/icheck.min.js') !!}"></script>

{{-- App JS --}}
<script src="{!! URL::asset('/js/app.js') !!}"></script>

{{-- Resource JS --}}
<script src="{!! URL::asset('/js/resource.js') !!}"></script>
