    <div class="banner-area-inner">
        <div class="banner-inner-area banner-area1">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-md-8 col-lg-6 col-xl-5">
                        <!-- banner text -->
                        <div class="banner-text-inner">
                            <div class="banner-shape-wrap">
                                <div class="banner-shape-inner">
                                    <img src="assets/img/banner/shaps1.png" alt="" class='shape shape1 rotate3d'>
                                    <img src="assets/img/banner/shaps2.png" alt="" class='shape shape2 rotate2d'>
                                    <img src="assets/img/banner/shaps3.png" alt="" class='shape shape3 rotate-2d'>
                                    <img src="assets/img/banner/shaps4.png" alt="" class='shape shape4 rotate3d'>
                                    <img src="assets/img/banner/shaps5.png" alt="" class='shape shape5 rotate2d'>
                                    <img src="assets/img/banner/shaps6.png" alt="" class='shape shape6 rotate-2d'>
                                    <img src="assets/img/banner/shaps7.png" alt="" class='shape shape7 rotate3d'>
                                </div>
                            </div>

                            <h1>{{env('APP_NAME')}} is for your internet app business</h1>
                            <p>Excepteur sint occaecat cupidatat non proident sunt in culpa qui officia deserunt mollit lorem ipsum anim id est laborum perspiciatis unde.</p>
                            <a href="#" class="btn">Download App</a>
                            <a href="#" class="btn">Discover More</a>
                        </div>
                        <!-- banner text -->
                    </div>
                    <div class="col-lg-5 offset-lg-1 col-md-4 offse-xl-2">
                        <!-- banner image-->
                        <div class="banner-image">
                            <img src="assets/img/banner/mockup.png" alt="">
                        </div>
                        <!--End of banner image-->
                    </div>
                </div>
            </div>
        </div>
    </div>