 <section class="pt-120 pb-110 bg-2">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="testimonial-author-arousel text-center">
                        <div class="testimonial-author-inner">
                            <div class="author-carousel owl-carousel">
                                <div class="single-author-imge">
                                    <img src="assets/img/feature/author3.png" alt="">
                                </div>
                                <div class="single-author-imge">
                                    <img src="assets/img/feature/author2.png" alt="">
                                </div>
                                <div class="single-author-imge">
                                    <img src="assets/img/feature/author1.png" alt="">
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="testimonial-author-comment text-center">
                        <div class="author-comment-carousel owl-carousel">
                            <div class="single-author-comment">
                                <h4>This is due to their excellent service, competitive<br> pricing and customer support. It’s throughly<br> refresing to get such
                                a personal touch.</h4>
                                <p>Shirley Smith</p>
                            </div>

                            <div class="single-author-comment">
                                <h4>This is due to their excellent service, competitive<br> pricing and customer support. It’s throughly<br> refresing to get such
                                a personal touch.</h4>
                                <p>Shirley Smith</p>
                            </div>
                            <div class="single-author-comment">
                                <h4>This is due to their excellent service, competitive<br> pricing and customer support. It’s throughly<br> refresing to get such
                                a personal touch.</h4>
                                <p>Shirley Smith</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>