    <section class="border-top pt-120 pb-80">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-6">
                    <!-- single counetr -->
                    <div class="single-counter text-center">
                        <span class="counter">4789</span>
                        <p>Downloads</p>
                    </div><!-- single counetr -->
                </div>
                <div class="col-md-3 col-sm-6">
                    <!-- single counetr -->
                    <div class="single-counter text-center">
                        <span class="counter">6389</span>
                        <p>Liks</p>
                    </div><!-- single counetr -->
                </div>
                <div class="col-md-3 col-sm-6">
                    <!-- single counetr -->
                    <div class="single-counter text-center">
                        <span class="counter">900</span>
                        <p>5 Star Reating</p>
                    </div><!-- single counetr -->
                </div>
                <div class="col-md-3 col-sm-6">
                    <!-- single counetr -->
                    <div class="single-counter text-center">
                        <span class="counter">489</span>
                        <p>Awards</p>
                    </div><!-- single counetr -->
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container -->
    </section>