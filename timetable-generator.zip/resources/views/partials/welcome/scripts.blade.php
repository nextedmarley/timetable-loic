<!-- ==== JQuery 3.3.1 js file==== -->
    <script src="{{asset('welcome/assets/js/jquery-3.3.1.min.js')}}"></script>

    <!-- ==== Bootstrap js file==== -->
    <script src="{{asset('welcome/assets/js/bootstrap.bundle.min.js')}}"></script>

    <!-- ==== JQuery Waypoint js file==== -->
    <script src="{{asset('welcome/assets/plugins/waypoints/jquery.waypoints.min.js')}}"></script>

    <!-- ==== Parsley js file==== -->
    <script src="{{asset('welcome/assets/plugins/parsley/parsley.min.js')}}"></script>

    <!-- ==== parallax js==== -->
    <script src="{{asset('welcome/assets/plugins/parallax/parallax.js')}}"></script>

    <!-- ==== Owl Carousel js file==== -->
    <script src="{{asset('welcome/assets/plugins/owl-carousel/owl.carousel.min.js')}}"></script>

    <!-- ==== Menu  js file==== -->
    <script src="{{asset('welcome/assets/js/menu.min.js')}}"></script>

    <!-- ===video popup=== -->
    <script src="{{asset('welcome/assets/plugins/Magnific-Popup/jquery.magnific-popup.min.js')}}"></script>

    <!-- ====Counter js file=== -->
    <script src="{{asset('welcome/assets/plugins/waypoints/jquery.counterup.min.js')}}"></script>

    <!-- ==== Script js file==== -->
    <script src="{{asset('welcome/assets/js/scripts.js')}}"></script>

    <!-- ==== Custom js file==== -->
    <script src="{{asset('welcome/assets/js/custom.js')}}"></script>