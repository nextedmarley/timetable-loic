    <section class="pt-120 pb-115" id='app'>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-12 col-lg-8">
                    <!-- section title -->
                    <div class="section-title text-center">
                        <h2>{{env('APP_NAME')}} App Screens</h2>
                        <p>Excepteur sint occaecat cupidatat non proident sunt in culpa qui officia deserunt mollit lorem ipsum anim id est laborum perspiciatis unde.</p>
                    </div>
                    <!-- End of section title -->
                </div>
            </div>
        </div>
        <div class="app-scrin-inner">
            <div class="app-carousel-inner">
                <div class="app-carousel owl-carousel">
                    <!-- slingle app image -->
                    <div class="single-app-image">
                        <img src="assets/img/feature/app-img.png" data-rjs="2" alt="">
                    </div>
                    <!-- slingle app image -->

                    <!-- slingle app image -->
                    <div class="single-app-image">
                        <img src="assets/img/feature/app-img2.png" data-rjs="2" alt="">
                    </div>
                    <!-- slingle app image -->

                    <!-- slingle app image -->
                    <div class="single-app-image">
                        <img src="assets/img/feature/app-img3.png" data-rjs="2" alt="">
                    </div>
                    <!-- slingle app image -->

                    <!-- slingle app image -->
                    <div class="single-app-image">
                        <img src="assets/img/feature/app-img4.png" data-rjs="2" alt="">
                    </div>
                    <!-- slingle app image -->

                    <!-- slingle app image -->
                    <div class="single-app-image">
                        <img src="assets/img/feature/app-img5.png" data-rjs="2" alt="">
                    </div>
                    <!-- slingle app image -->
                </div>
            </div>
        </div>
    </section>