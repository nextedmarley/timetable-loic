<section class="pb-110" id='features'>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-12 col-lg-8">
                    <!-- section title -->
                    <div class="section-title text-center">
                        <h2>App Advance Features</h2>
                        <p>Excepteur sint occaecat cupidatat non proident sunt in culpa qui officia deserunt mollit lorem ipsum anim id est laborum perspiciatis unde.</p>
                    </div>
                    <!-- End of section title -->
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-xl-10 col-lg-12">
                    <div class="feature-carousel owl-carousel">
                        <!-- single feature inner -->
                        <div class="single-feature-inner text-center">
                            <div class="feature-icon"><img src="assets/img/icons/project-management.svg" class="svg" alt=""></div>
                            <h5>New Artwork<br> Unveiled</h5>
                            <p>There are many variations of passages of lorem Ipsum but majority have suffered.</p>
                        </div>
                        <!-- End of single feature inner -->

                        <!-- single feature inner -->
                        <div class="single-feature-inner text-center">
                            <div class="feature-icon"><img src="assets/img/icons/solution.svg" class="svg" alt=""></div>
                            <h5>Company Growth Strategy</h5>
                            <p>There are many variations of passages of lorem Ipsum but majority have suffered.</p>
                        </div>
                        <!-- End of single feature inner -->

                        <!-- single feature inner -->
                        <div class="single-feature-inner text-center">
                            <div class="feature-icon"><img src="assets/img/icons/planning.svg" class="svg" alt=""></div>
                            <h5>Perfect Application Intergration</h5>
                            <p>There are many variations of passages of lorem Ipsum but majority have suffered.</p>
                        </div>
                        <!-- End of single feature inner -->

                        <!-- single feature inner -->
                        <div class="single-feature-inner text-center">
                            <div class="feature-icon"><img src="assets/img/icons/goal.svg" class="svg" alt=""></div>
                            <h5>Creative App<br>Display</h5>
                            <p>There are many variations of passages of lorem Ipsum but majority have suffered.</p>
                        </div><!-- End of single feature inner -->
                    </div><!--/.feature-carousel-->
                </div><!--/.col-->
            </div><!--/.row-->
        </div><!--/.container-->
    </section>