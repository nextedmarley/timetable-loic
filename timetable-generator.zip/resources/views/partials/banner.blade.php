 	<div class="login-form-header">
 		<div class="pull-left"><a href="/" class="btn btn-light" style="color: #fff; margin-top: auto;margin-bottom: auto; border-color: #1ce;display: inline-block; height: 100%">{{__('Go Back')}}</a></div>
        <h3 class="text-center">Genius Team ! {{ date('Y')}} <br></h3>
        <h4><a href="mailto:ngounoubosseloic@gmail.com" >ngounoubosseloic@gmail.com</a></h4>
        <h4><a href="tel:+237690441515"><span class="pull-right fa fa-phone text-center">690441515</span></a>
        </h4>
    </div>