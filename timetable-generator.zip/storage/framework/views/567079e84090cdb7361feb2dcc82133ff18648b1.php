<p>Hello <?php echo e($professor->name); ?></p>
<p>Based on the new timetables generated, your weekly schedule is as follows</p>

<div style="padding: 30px;">
    <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day => $daySchedules): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(count($daySchedules)): ?>
            <h2><?php echo e($day); ?>s</h2>
            <?php $__currentLoopData = $daySchedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h3><?php echo e($schedule->timeslot->time); ?></h3>
                <p><?php echo e($schedule->course->course_code); ?> - <?php echo e($schedule->course->name); ?></p>
                <p><?php echo e($schedule->college_class->name); ?></p>
                <p>Room <?php echo e($schedule->room->name); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<a style="font-family: Avenir, Helvetica, sans-serif; box-sizing: border-box; text-decoration: none; padding-top: 5px;
padding-bottom: 5px; padding-left: 5px; padding-right: 5px; background: #5F9EA0; color: #FFFFFF; margin-left: 10%;" href="<?php echo e($profUrl); ?>">Click here to view online</a>

<a style="font-family: Avenir, Helvetica, sans-serif; box-sizing: border-box; text-decoration: none; padding-top: 5px;
padding-bottom: 5px; padding-left: 5px; padding-right: 5px; background: #5F9EA0; color: #FFFFFF; margin-left: 10%;" href="<?php echo e($url); ?>">Click here to view all timetables</a>