<div class="col-md-12 text-center alert  ">
	Copyright Genius Team <?php echo e(date("Y")); ?>

</div>