    <!-- CSS Files -->
    <!--==== Google Fonts ====-->
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700" rel="stylesheet">

    <!--==== Bootstrap css file ====-->
    <link rel="stylesheet" href="<?php echo e(asset('welcome/assets/css/bootstrap.min.css')); ?>">

    <!--==== Font-Awesome css file ====-->
    <link rel="stylesheet" href="<?php echo e(asset('welcome/assets/css/font-awesome.min.css')); ?>">

    <!-- Owl Carusel css file -->
    <link rel="stylesheet" href="<?php echo e(asset('welcome/assets/plugins/owl-carousel/owl.carousel.min.css')); ?>">

    <!-- ====video poppu css==== -->
    <link rel="stylesheet" href="<?php echo e(asset('welcome/assets/plugins/Magnific-Popup/magnific-popup.css')); ?>">

    <!--==== Style css file ====-->
    <link rel="stylesheet" href="<?php echo e(asset('welcome/assets/css/style.css')); ?>">

    <!--==== Responsive css file ====-->
    <link rel="stylesheet" href="<?php echo e(asset('welcome/assets/css/responsive.css')); ?>">

    <!--==== Custom css file ====-->
    <link rel="stylesheet" href="<?php echo e(asset('welcome/assets/css/custom.css')); ?>">